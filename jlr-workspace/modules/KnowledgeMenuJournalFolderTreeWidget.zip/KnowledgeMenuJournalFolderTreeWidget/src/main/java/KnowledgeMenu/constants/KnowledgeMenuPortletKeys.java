package KnowledgeMenu.constants;

/**
 * @author carlos
 */
public class KnowledgeMenuPortletKeys {

	public static final String KNOWLEDGEMENU =
		"KnowledgeMenu_KnowledgeMenuPortlet";

}